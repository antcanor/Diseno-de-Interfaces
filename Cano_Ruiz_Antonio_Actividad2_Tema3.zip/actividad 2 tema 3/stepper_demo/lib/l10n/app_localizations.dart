import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_es.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('es'),
  ];

  /// No description provided for @appTitle.
  ///
  /// In es, this message translates to:
  /// **'Compra de Entradas'**
  String get appTitle;

  /// No description provided for @eventName.
  ///
  /// In es, this message translates to:
  /// **'Gran Concierto Sinfónico de Primavera'**
  String get eventName;

  /// No description provided for @eventSubtitle.
  ///
  /// In es, this message translates to:
  /// **'Auditorio y Centro de Congresos Víctor Villegas'**
  String get eventSubtitle;

  /// Número de entradas con soporte plural
  ///
  /// In es, this message translates to:
  /// **'{count, plural, =1{1 entrada} other{{count} entradas}}'**
  String ticketsCount(num count);

  /// No description provided for @ticketUnitPrice.
  ///
  /// In es, this message translates to:
  /// **'4,50 € por entrada'**
  String get ticketUnitPrice;

  /// Precio total con formato de moneda
  ///
  /// In es, this message translates to:
  /// **'Precio total: {price}'**
  String totalPrice(String price);

  /// Fecha del evento formateada
  ///
  /// In es, this message translates to:
  /// **'Fecha del evento: {date}'**
  String eventDateLabel(String date);

  /// No description provided for @stepperSemanticLabel.
  ///
  /// In es, this message translates to:
  /// **'Selector de cantidad de entradas'**
  String get stepperSemanticLabel;

  /// No description provided for @decrementTooltip.
  ///
  /// In es, this message translates to:
  /// **'Restar entrada'**
  String get decrementTooltip;

  /// No description provided for @incrementTooltip.
  ///
  /// In es, this message translates to:
  /// **'Sumar entrada'**
  String get incrementTooltip;

  /// No description provided for @maxReachedMessage.
  ///
  /// In es, this message translates to:
  /// **'Has llegado al máximo'**
  String get maxReachedMessage;

  /// No description provided for @ratingTitle.
  ///
  /// In es, this message translates to:
  /// **'Valoración del evento'**
  String get ratingTitle;

  /// No description provided for @confirmPurchase.
  ///
  /// In es, this message translates to:
  /// **'Comprar entradas'**
  String get confirmPurchase;

  /// No description provided for @purchaseSuccess.
  ///
  /// In es, this message translates to:
  /// **'¡Has comprado {count, plural, =1{1 entrada} other{{count} entradas}} por {price}!'**
  String purchaseSuccess(num count, String price);

  /// No description provided for @languageLabel.
  ///
  /// In es, this message translates to:
  /// **'Idioma'**
  String get languageLabel;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'es'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'es':
      return AppLocalizationsEs();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
